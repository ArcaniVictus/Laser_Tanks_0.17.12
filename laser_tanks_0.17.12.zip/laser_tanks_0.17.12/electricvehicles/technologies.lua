table.insert(data.raw.technology["laser-rifle-1"].effects,{
        type = "unlock-recipe",
        recipe = "electric-vehicles-lo-voltage-transformer"
      })
table.insert(data.raw.technology["laser-rifle-1"].effects,{
        type = "unlock-recipe",
        recipe = "electric-vehicles-regen-brake-controller"
      })
table.insert(data.raw.technology["laser-rifle-2"].effects,{
        type = "unlock-recipe",
        recipe = "electric-vehicles-hi-voltage-transformer"
      })