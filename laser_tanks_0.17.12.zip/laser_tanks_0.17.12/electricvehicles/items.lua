-- Support for  Schallfalke's Schall Transport Group mod
local subgroup_eve = "electric-vehicles-equipment"

if mods["SchallTransportGroup"] then
	subgroup_eve = "vehicle-equipment"
end

data:extend
{
  {
    type = "item",
    name = "electric-vehicles-lo-voltage-transformer",
    icon = "__laser_tanks__/graphics/icons/lo-voltage-transformer.png",
    icon_size = 32,
    placed_as_equipment_result = "electric-vehicles-lo-voltage-transformer",
    flags = {},
    subgroup = subgroup_eve, --Support for  Schallfalke's Schall Transport Group mod
    order = "c",
    stack_size = 10,
  },
  {
    type = "item",
    name = "electric-vehicles-hi-voltage-transformer",
    icon = "__laser_tanks__/graphics/icons/hi-voltage-transformer.png",
    icon_size = 32,
    placed_as_equipment_result = "electric-vehicles-hi-voltage-transformer",
    flags = {},
    subgroup = subgroup_eve, --Support for  Schallfalke's Schall Transport Group mod
    order = "d",
    stack_size = 10,
  },
  {
    type = "item",
    name = "electric-vehicles-regen-brake-controller",
    icon = "__laser_tanks__/graphics/icons/regen-brake-controller.png",
    icon_size = 32,
    placed_as_equipment_result = "electric-vehicles-regen-brake-controller",
    flags = {},
    subgroup = subgroup_eve, --Support for  Schallfalke's Schall Transport Group mod
    order = "e",
    stack_size = 10,
  },
}
