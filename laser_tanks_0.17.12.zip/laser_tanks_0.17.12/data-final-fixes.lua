data.raw.car["lasertank"].guns = { "tank-laser-cannon", "vehicle-laser-gun", "tank-flamethrower" }
data.raw.car["lasertank"].minable = {mining_time = 1, result = "lasertank"}
data.raw.car["lasercar"].guns = { "vehicle-laser-gun" }
data.raw.car["lasercar"].minable = {mining_time = 1, result = "lasercar"}

if data.raw["locomotive"]["electric-vehicles-electric-locomotive"] and data.raw.item["electric-vehicles-electric-locomotive"] then
	data.raw["locomotive"]["electric-vehicles-electric-locomotive"].minable = {mining_time = 1, result = "electric-vehicles-electric-locomotive"}
end